# HelpDesk 360 — One Folder App

## 1. Install dependency

```bash
pip install -r requirements.txt
```

## 2. Run

```bash
python app.py
```

## 3. Open

Go to: http://localhost:5173

Demo technician: arjun@northstar.com / arjun123
Demo employee: priya@northstar.com / priya123

The SQLite database is created automatically in this folder when the app starts.
