#!/usr/bin/env python3
from flask import Flask, request, jsonify, send_from_directory, g
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timezone
import sqlite3, os, re, json, math, secrets

ROOT = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(ROOT, 'helpdesk.db')
MODEL_PATH = os.path.join(ROOT, 'priority_model.json')
app = Flask(__name__)

CATEGORIES = ['hardware', 'network', 'software', 'account-access']
PRIORITIES = ['low', 'medium', 'high', 'urgent']
STATUSES = ['open', 'in-progress', 'resolved', 'closed']
TOKENS = {}

TRAINING_DATA = [
 ('laptop will not boot black screen broken keyboard device dead', 'urgent'),
 ('server down production outage everyone cannot access service', 'urgent'),
 ('account locked cannot login payroll deadline today', 'urgent'),
 ('wifi outage meeting room internet disconnected for whole team', 'urgent'),
 ('vpn disconnects every few minutes remote work blocked', 'high'),
 ('email not syncing since morning cannot send messages', 'high'),
 ('projector display not working before client meeting', 'high'),
 ('software license expired adobe application unavailable', 'high'),
 ('need access to shared drive folder', 'medium'),
 ('install chrome update on laptop', 'medium'),
 ('printer has paper jam on third floor', 'medium'),
 ('request access to design tool', 'medium'),
 ('how do i change my desktop wallpaper', 'low'),
 ('mouse battery needs replacement', 'low'),
 ('request new monitor for desk', 'low'),
 ('question about password policy', 'low'),
]

def now(): return datetime.now(timezone.utc).isoformat()
def tokenize(text): return re.findall(r'[a-z0-9]+', (text or '').lower())

def train_model():
    labels = {x[1] for x in TRAINING_DATA}; counts={l:{} for l in labels}; totals={l:0 for l in labels}; docs={l:0 for l in labels}; vocab=set()
    for text,label in TRAINING_DATA:
        docs[label]+=1
        for token in tokenize(text): counts[label][token]=counts[label].get(token,0)+1; totals[label]+=1; vocab.add(token)
    model={'labels':sorted(labels),'counts':counts,'totals':totals,'docs':docs,'vocab':sorted(vocab),'trained_at':now()}
    with open(MODEL_PATH,'w') as f: json.dump(model,f,indent=2)
    return model

def load_model():
    try:
        with open(MODEL_PATH) as f: return json.load(f)
    except Exception: return train_model()
MODEL=load_model()

def predict_priority(text):
    words=tokenize(text); total_docs=sum(MODEL['docs'].values()); vocab_size=len(MODEL['vocab']); scores={}
    for label in MODEL['labels']:
        score=math.log((MODEL['docs'][label]+1)/(total_docs+len(MODEL['labels'])))
        denom=MODEL['totals'][label]+vocab_size
        for word in words: score += math.log((MODEL['counts'][label].get(word,0)+1)/denom)
        scores[label]=score
    ranked=sorted(scores.items(),key=lambda x:x[1],reverse=True)
    best=ranked[0][0]
    confidence=round(1/(1+math.exp(-(ranked[0][1]-ranked[1][1]))),2) if len(ranked)>1 else 1
    return best, confidence

def db():
    if 'db' not in g:
        g.db=sqlite3.connect(DB_PATH); g.db.row_factory=sqlite3.Row; g.db.execute('PRAGMA foreign_keys=ON')
    return g.db
@app.teardown_appcontext
def close_db(exc):
    conn=g.pop('db',None)
    if conn: conn.close()

def init_db():
    conn=sqlite3.connect(DB_PATH); conn.row_factory=sqlite3.Row; conn.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('employee','technician')), avatar TEXT);
    CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL, priority TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', reporter_id INTEGER NOT NULL, assignee_id INTEGER, predicted_priority TEXT, prediction_confidence REAL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(reporter_id) REFERENCES users(id), FOREIGN KEY(assignee_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS status_history(id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL, changed_by INTEGER NOT NULL, old_status TEXT, new_status TEXT NOT NULL, note TEXT, created_at TEXT NOT NULL, FOREIGN KEY(ticket_id) REFERENCES tickets(id) ON DELETE CASCADE, FOREIGN KEY(changed_by) REFERENCES users(id));
    ''')
    users=conn.execute('SELECT COUNT(*) c FROM users').fetchone()['c']
    if not users:
        seed=[('Arjun Kumar','arjun@northstar.com','arjun123','technician','AK'),('Priya Shah','priya@northstar.com','priya123','employee','PS'),('Rahul Menon','rahul@northstar.com','rahul123','employee','RM'),('Nisha Kapoor','nisha@northstar.com','nisha123','employee','NK'),('Dev Patel','dev@northstar.com','dev123','employee','DP')]
        conn.executemany('INSERT INTO users(name,email,password_hash,role,avatar) VALUES(?,?,?,?,?)',[(n,e,generate_password_hash(p),r,a) for n,e,p,r,a in seed])
        tech=conn.execute("SELECT id FROM users WHERE role='technician' LIMIT 1").fetchone()['id']; employees=[r['id'] for r in conn.execute("SELECT id FROM users WHERE role='employee'").fetchall()]
        seed_tickets=[('Laptop won’t connect to Wi-Fi','Connection drops every few minutes in the office.','network','urgent','in-progress',employees[0],tech),('Adobe Creative Cloud license expired','The design team cannot open Illustrator.','software','high','open',employees[1],None),('Meeting room display is not working','Screen shows no signal in room 3.','hardware','medium','in-progress',employees[2],tech),('Unable to access shared finance drive','Permission denied when opening the folder.','account-access','urgent','resolved',employees[3],tech),('VPN disconnects every few minutes','Remote connection keeps dropping.','network','high','open',employees[0],None)]
        for t in seed_tickets:
            created=now(); cur=conn.execute('INSERT INTO tickets(title,description,category,priority,status,reporter_id,assignee_id,predicted_priority,prediction_confidence,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(*t,t[3],.9,created,created));
            if t[4]!='open': conn.execute('INSERT INTO status_history(ticket_id,changed_by,old_status,new_status,note,created_at) VALUES(?,?,?,?,?,?)',(cur.lastrowid,tech,'open',t[4],'Seeded demo status',created))
        conn.commit()
    conn.close()
init_db()

def auth(required_role=None):
    token=request.headers.get('Authorization','').replace('Bearer ','').strip(); uid=TOKENS.get(token)
    if not uid: return None, (jsonify(error='Please log in first'),401)
    user=db().execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
    if not user or (required_role and user['role']!=required_role): return None,(jsonify(error='You do not have permission for this action'),403)
    return user,None

def ticket_row(row):
    d=dict(row); d['id_label']=f"#HD-{d['id']:04d}"; d['reported_by']=d.pop('reporter_name'); d['assigned_to']=d.pop('assignee_name'); d['assigned_avatar']=d.pop('assignee_avatar'); return d
TICKET_SELECT='''SELECT t.*, u.name reporter_name, a.name assignee_name, a.avatar assignee_avatar FROM tickets t JOIN users u ON u.id=t.reporter_id LEFT JOIN users a ON a.id=t.assignee_id'''

@app.get('/api/health')
def health(): return jsonify(ok=True, model_trained_at=MODEL['trained_at'])
@app.post('/api/login')
def login():
    data=request.get_json(silent=True) or {}; user=db().execute('SELECT * FROM users WHERE email=?',(data.get('email','').strip().lower(),)).fetchone()
    if not user or not check_password_hash(user['password_hash'],data.get('password','')): return jsonify(error='Invalid email or password'),401
    token=secrets.token_urlsafe(32); TOKENS[token]=user['id']; return jsonify(token=token,user={k:user[k] for k in ('id','name','email','role','avatar')})
@app.get('/api/me')
def me():
    user,err=auth()
    if err:return err
    return jsonify(user={k:user[k] for k in ('id','name','email','role','avatar')})
@app.get('/api/dashboard')
def dashboard():
    user,err=auth('technician')
    if err:return err
    c=db(); return jsonify(open=c.execute("SELECT COUNT(*) n FROM tickets WHERE status IN ('open','in-progress')").fetchone()['n'],urgent=c.execute("SELECT COUNT(*) n FROM tickets WHERE priority='urgent' AND status NOT IN ('resolved','closed')").fetchone()['n'],assigned=c.execute('SELECT COUNT(*) n FROM tickets WHERE assignee_id IS NOT NULL AND status NOT IN (\'resolved\',\'closed\')').fetchone()['n'],resolved=c.execute("SELECT COUNT(*) n FROM tickets WHERE status IN ('resolved','closed')").fetchone()['n'])
@app.get('/api/technicians')
def technicians():
    user,err=auth()
    if err:return err
    return jsonify(technicians=[dict(x) for x in db().execute("SELECT id,name,email,avatar FROM users WHERE role='technician'").fetchall()])
@app.get('/api/tickets')
def list_tickets():
    user,err=auth()
    if err:return err
    c=db(); q=TICKET_SELECT; args=[]; filters=[]
    if user['role']=='employee': filters.append('t.reporter_id=?'); args.append(user['id'])
    for key in ('status','priority','category','assignee_id'):
        if request.args.get(key): filters.append(f't.{key}=?'); args.append(request.args[key])
    if filters:q+=' WHERE '+' AND '.join(filters)
    q+=' ORDER BY CASE t.priority WHEN \'urgent\' THEN 1 WHEN \'high\' THEN 2 WHEN \'medium\' THEN 3 ELSE 4 END, t.updated_at DESC'
    return jsonify(tickets=[ticket_row(x) for x in c.execute(q,args).fetchall()])
@app.post('/api/tickets')
def create_ticket():
    user,err=auth('employee')
    if err:return err
    data=request.get_json(silent=True) or {}; title=(data.get('title') or '').strip(); desc=(data.get('description') or '').strip(); category=data.get('category','').lower().replace(' ','-')
    if not title or not desc or category not in CATEGORIES: return jsonify(error='Title, description and a valid category are required'),400
    if len(title)>140 or len(desc)>5000: return jsonify(error='Title or description is too long'),400
    predicted,confidence=predict_priority(title+' '+desc); priority=data.get('priority','').lower() or predicted
    if priority not in PRIORITIES:return jsonify(error='Invalid priority'),400
    t=now(); c=db(); cur=c.execute('INSERT INTO tickets(title,description,category,priority,status,reporter_id,predicted_priority,prediction_confidence,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(title,desc,category,priority,'open',user['id'],predicted,confidence,t,t)); c.execute('INSERT INTO status_history(ticket_id,changed_by,old_status,new_status,note,created_at) VALUES(?,?,?,?,?,?)',(cur.lastrowid,user['id'],None,'open','Ticket created',t)); c.commit(); row=c.execute(TICKET_SELECT+' WHERE t.id=?',(cur.lastrowid,)).fetchone(); return jsonify(ticket=ticket_row(row),ml={'predicted_priority':predicted,'confidence':confidence}),201
@app.patch('/api/tickets/<int:ticket_id>')
def update_ticket(ticket_id):
    user,err=auth('technician')
    if err:return err
    data=request.get_json(silent=True) or {}; c=db(); old=c.execute('SELECT * FROM tickets WHERE id=?',(ticket_id,)).fetchone()
    if not old:return jsonify(error='Ticket not found'),404
    updates=[]; args=[]
    if 'status' in data:
        if data['status'] not in STATUSES:return jsonify(error='Invalid status'),400
        order={s:i for i,s in enumerate(STATUSES)}
        if order[data['status']] < order[old['status']]:return jsonify(error='Status cannot move backwards'),400
        if data['status']!=old['status']:
            c.execute('INSERT INTO status_history(ticket_id,changed_by,old_status,new_status,note,created_at) VALUES(?,?,?,?,?,?)',(ticket_id,user['id'],old['status'],data['status'],data.get('note','Status updated'),now())); updates+=['status=?'];args+=[data['status']]
    if 'assignee_id' in data:
        assignee=c.execute("SELECT id FROM users WHERE id=? AND role='technician'",(data['assignee_id'],)).fetchone()
        if not assignee:return jsonify(error='Assignee must be an existing technician'),400
        updates+=['assignee_id=?'];args+=[data['assignee_id']]
    if 'priority' in data:
        if data['priority'] not in PRIORITIES:return jsonify(error='Invalid priority'),400
        updates+=['priority=?'];args+=[data['priority']]
    if not updates:return jsonify(error='No valid changes supplied'),400
    updates+=['updated_at=?'];args+=[now(),ticket_id]; c.execute('UPDATE tickets SET '+','.join(updates)+' WHERE id=?',args); c.commit(); row=c.execute(TICKET_SELECT+' WHERE t.id=?',(ticket_id,)).fetchone(); return jsonify(ticket=ticket_row(row))
@app.get('/api/tickets/<int:ticket_id>/history')
def history(ticket_id):
    user,err=auth();
    if err:return err
    row=db().execute('SELECT reporter_id FROM tickets WHERE id=?',(ticket_id,)).fetchone()
    if not row:return jsonify(error='Ticket not found'),404
    if user['role']=='employee' and row['reporter_id']!=user['id']:return jsonify(error='Not allowed'),403
    h=db().execute('SELECT sh.*,u.name changed_by_name FROM status_history sh JOIN users u ON u.id=sh.changed_by WHERE ticket_id=? ORDER BY created_at DESC',(ticket_id,)).fetchall(); return jsonify(history=[dict(x) for x in h])

HTML = '<!doctype html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>HelpDesk 360 — IT Support Command Center</title>\n  <link rel="preconnect" href="https://fonts.googleapis.com">\n  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">\n  <link rel="stylesheet" href="styles.css" />\n</head>\n<body>\n  <div class="app-shell">\n    <aside class="sidebar">\n      <div class="brand"><div class="brand-mark"><span></span><span></span><span></span></div><div><strong>HelpDesk</strong><small>360 / COMMAND CENTER</small></div></div>\n      <div class="workspace-switcher"><div class="workspace-icon">N</div><div><b>Northstar HQ</b><span>IT Operations</span></div><span class="chevron">⌄</span></div>\n      <nav class="nav"><p class="nav-label">WORKSPACE</p><button class="nav-item active" data-view="overview"><span class="nav-icon">◈</span>Overview</button><button class="nav-item" data-view="queue"><span class="nav-icon">≡</span>Ticket queue <em>12</em></button><button class="nav-item" data-view="my-tickets"><span class="nav-icon">□</span>My tickets</button><button class="nav-item" data-view="team"><span class="nav-icon">♙</span>Technicians</button><p class="nav-label second">MANAGE</p><button class="nav-item" data-view="analytics"><span class="nav-icon">⌁</span>Analytics</button><button class="nav-item" data-view="settings"><span class="nav-icon">⚙</span>Settings</button></nav>\n      <div class="sidebar-bottom"><div class="mini-status"><span class="pulse"></span><div><b>All systems operational</b><small>Last checked 2 min ago</small></div></div><div class="user-card"><div class="avatar avatar-purple">AK</div><div><b>Arjun Kumar</b><span>Support lead</span></div><span class="more">•••</span></div></div>\n    </aside>\n    <main class="main">\n      <header class="topbar"><div class="breadcrumb"><span>Workspace</span><b>/</b><strong id="page-title">Overview</strong></div><div class="top-actions"><button class="icon-btn" title="Search">⌕</button><button class="icon-btn notification" title="Notifications">♧<i></i></button><div class="top-avatar">AK</div></div></header>\n      <div class="content">\n        <section class="hero"><div><p class="eyebrow">THURSDAY, 15 OCTOBER 2026 <span class="live-dot"></span> LIVE</p><h1>Good morning, Arjun<span>.</span></h1><p class="hero-sub">Here’s what needs your attention today.</p></div><button class="primary-btn" id="new-ticket"><span>＋</span> New ticket</button></section>\n        <section class="metric-grid"><article class="metric-card metric-blue"><div class="metric-top"><span>OPEN ISSUES</span><span class="metric-icon">◌</span></div><div class="metric-value">24</div><div class="metric-foot"><span class="trend up">↗ 12%</span><span>vs last week</span></div><div class="sparkline blue"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div></article><article class="metric-card metric-orange"><div class="metric-top"><span>URGENT REQUESTS</span><span class="metric-icon">!</span></div><div class="metric-value">06</div><div class="metric-foot"><span class="trend down">↘ 8%</span><span>vs last week</span></div><div class="sparkline orange"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div></article><article class="metric-card metric-purple"><div class="metric-top"><span>ASSIGNED TO TEAM</span><span class="metric-icon">♙</span></div><div class="metric-value">18</div><div class="metric-foot"><span class="trend up">↗ 24%</span><span>vs last week</span></div><div class="sparkline purple"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div></article><article class="metric-card metric-green"><div class="metric-top"><span>RESOLVED THIS WEEK</span><span class="metric-icon">✓</span></div><div class="metric-value">42</div><div class="metric-foot"><span class="trend up">↗ 18%</span><span>vs last week</span></div><div class="sparkline green"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div></article></section>\n        <section class="dashboard-grid"><div class="panel queue-panel"><div class="panel-heading"><div><h2>Priority queue</h2><p>Requests that need your attention</p></div><button class="text-btn" data-view="queue">View all <span>→</span></button></div><div class="queue-tabs"><button class="tab active">All <b>12</b></button><button class="tab">Urgent <b class="orange-count">6</b></button><button class="tab">Unassigned <b>3</b></button></div><div class="ticket-list" id="ticket-list"></div></div><div class="right-column"><div class="panel chart-panel"><div class="panel-heading"><div><h2>Resolution health</h2><p>Average time to close a ticket</p></div><button class="period-btn">This week⌄</button></div><div class="chart-wrap"><div class="chart-y"><span>8h</span><span>6h</span><span>4h</span><span>2h</span><span>0h</span></div><div class="chart"><div class="gridline g1"></div><div class="gridline g2"></div><div class="gridline g3"></div><div class="gridline g4"></div><svg viewBox="0 0 500 170" preserveAspectRatio="none"><defs><linearGradient id="area" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#7567ff" stop-opacity=".24"/><stop offset="1" stop-color="#7567ff" stop-opacity="0"/></linearGradient></defs><path class="area" d="M0,125 C35,118 40,120 72,110 S120,95 145,105 S195,90 220,88 S260,108 290,80 S330,70 355,77 S390,52 420,62 S450,40 500,35 V170 H0Z"/><path class="line" d="M0,125 C35,118 40,120 72,110 S120,95 145,105 S195,90 220,88 S260,108 290,80 S330,70 355,77 S390,52 420,62 S450,40 500,35"/></svg><div class="chart-x"><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span></div></div></div><div class="chart-summary"><strong>3h 42m</strong><span class="trend up">↘ 16% faster</span><small>than last week</small></div></div><div class="panel activity-panel"><div class="panel-heading"><div><h2>Recent activity</h2><p>Latest updates across your workspace</p></div><button class="more-btn">•••</button></div><div class="activity-list"><div class="activity"><div class="avatar avatar-orange">PS</div><div><p><b>Priya Shah</b> assigned <a>#HD-1042</a> to you</p><small>8 minutes ago</small></div></div><div class="activity"><div class="activity-icon green-icon">✓</div><div><p><b>HD-1038</b> was marked as resolved</p><small>24 minutes ago</small></div></div><div class="activity"><div class="avatar avatar-blue">RM</div><div><p><b>Rahul Menon</b> added a comment on <a>#HD-1035</a></p><small>1 hour ago</small></div></div></div></div></div></section>\n      </div>\n    </main>\n  </div>\n  <div class="modal-backdrop" id="modal"><div class="modal"><button class="modal-close" id="close-modal">×</button><p class="eyebrow">NEW REQUEST</p><h2>What can we help with?</h2><p class="modal-sub">Create a ticket and our support team will take it from here.</p><form id="ticket-form"><label>Title<input required name="title" placeholder="e.g. Laptop won’t connect to Wi-Fi" /></label><label>Description<textarea required name="description" rows="4" placeholder="Tell us a little more about the issue..."></textarea></label><div class="form-row"><label>Category<select name="category"><option>Network</option><option>Hardware</option><option>Software</option><option>Account access</option></select></label><label>Priority<select name="priority"><option>Medium</option><option>Low</option><option>High</option><option>Urgent</option></select></label></div><button class="primary-btn full" type="submit">Submit request <span>→</span></button></form></div></div>\n  <div class="toast" id="toast"><span>✓</span> Ticket created successfully</div>\n  <script src="app.js"></script>\n</body>\n</html>'
CSS = "\n/* Backend-connected states */\nbody.locked .app-shell{filter:blur(4px);pointer-events:none}.auth-screen{position:fixed;inset:0;background:#171822;z-index:20;display:grid;place-items:center;padding:20px}.auth-card{width:min(410px,100%);background:#fff;border-radius:18px;padding:34px;box-shadow:0 25px 80px #0005}.auth-logo{display:flex;align-items:center;gap:11px;margin-bottom:42px}.auth-logo strong{font:700 17px 'Space Grotesk';display:block}.auth-logo small{display:block;color:#9a9aa8;font-size:8px;letter-spacing:1.5px;margin-top:3px}.auth-card h1{font:700 30px 'Space Grotesk';margin:0 0 8px}.auth-card h1 span{color:#7567ff}.auth-sub{color:#9899a6;margin:0 0 27px;font-size:13px}.auth-card label{font-size:11px;font-weight:700;color:#686978;display:block;margin-bottom:15px}.auth-card input{font:400 12px 'DM Sans';display:block;margin-top:7px;width:100%;border:1px solid #e5e5eb;border-radius:8px;padding:12px;outline:0}.auth-card input:focus{border-color:#7567ff;box-shadow:0 0 0 3px #7567ff15}.login-error{color:#ec6c62;font-size:11px;min-height:18px;margin:10px 0 0}.demo-logins{border-top:1px solid #eeeef3;margin-top:20px;padding-top:16px}.demo-logins>small{font-size:9px;letter-spacing:1px;color:#aaa}.demo-logins button{display:flex;width:100%;border:0;background:#f7f7fa;border-radius:7px;margin-top:8px;padding:9px 11px;color:#555665;text-align:left;font:500 10px 'DM Sans';justify-content:space-between;cursor:pointer}.demo-logins button b{color:#7567ff;font-weight:600}.logout-btn{margin-left:auto;background:none;border:0;color:#888;cursor:pointer;font-size:17px}.empty-state{padding:45px 10px;text-align:center;color:#a0a1ad;font-size:12px}.detail-backdrop{position:fixed;inset:0;background:#171822aa;backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;z-index:10}.detail-card{background:#fff;width:min(570px,calc(100% - 30px));border-radius:16px;padding:29px;position:relative;box-shadow:0 20px 70px #0003}.detail-card h2{font:700 24px 'Space Grotesk';margin:0 0 12px}.detail-desc{font-size:13px;line-height:1.6;color:#777886;background:#fafafd;padding:12px;border-radius:8px}.detail-meta{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:20px 0;border-bottom:1px solid #eeeef3;padding-bottom:18px}.detail-meta span{font-size:10px;color:#a0a1ae}.detail-meta strong{display:block;color:#3a3b49;font-size:12px;margin-top:5px}.priority-text.urgent{color:#ef7b42}.priority-text.high{color:#e19a42}.priority-text.medium{color:#5f98df}.detail-card h3{font:700 13px 'Space Grotesk';margin:0 0 10px}.history>div{display:flex;gap:9px;align-items:flex-start}.history i{width:7px;height:7px;border-radius:50%;background:#7567ff;margin-top:5px;box-shadow:0 0 0 4px #7567ff18}.history p{font-size:11px;color:#7c7d8a;margin:0 0 11px}.history small{display:block;color:#aaa;font-size:9px;margin-top:3px}.detail-actions{display:flex;gap:10px;border-top:1px solid #eeeef3;padding-top:17px;margin-top:8px}.detail-actions select{flex:1;border:1px solid #e5e5eb;border-radius:8px;padding:10px;font:12px 'DM Sans'}\n"
JS = 'const API=\'/api\';\nlet token=localStorage.getItem(\'helpdesk_token\'); let currentUser=null; let allTickets=[];\nconst $=s=>document.querySelector(s); const esc=s=>String(s??\'\').replace(/[&<>"\']/g,c=>({\'&\':\'&amp;\',\'<\':\'&lt;\',\'>\':\'&gt;\',\'"\':\'&quot;\',"\'":\'&#39;\'}[c]));\nasync function api(path, options={}){const res=await fetch(API+path,{...options,headers:{\'Content-Type\':\'application/json\',...(token?{Authorization:`Bearer ${token}`}:{}) ,...(options.headers||{})}});const data=await res.json().catch(()=>({}));if(!res.ok)throw new Error(data.error||`Request failed (${res.status})`);return data}\nfunction toast(message,good=true){const t=$(\'#toast\');t.innerHTML=`<span>${good?\'✓\':\'!\'}</span> ${esc(message)}`;t.classList.add(\'show\');setTimeout(()=>t.classList.remove(\'show\'),3000)}\nfunction showLogin(){document.body.classList.add(\'locked\');document.body.insertAdjacentHTML(\'afterbegin\',`<div class="auth-screen" id="auth-screen"><div class="auth-card"><div class="auth-logo"><div class="brand-mark"><span></span><span></span><span></span></div><div><strong>HelpDesk</strong><small>360 / COMMAND CENTER</small></div></div><p class="eyebrow">SECURE WORKSPACE</p><h1>Welcome back<span>.</span></h1><p class="auth-sub">Sign in to manage your support requests.</p><form id="login-form"><label>Work email<input required type="email" id="email" value="arjun@northstar.com" /></label><label>Password<input required type="password" id="password" value="arjun123" /></label><button class="primary-btn full" type="submit">Sign in <span>→</span></button><p class="login-error" id="login-error"></p></form><div class="demo-logins"><small>DEMO ACCOUNTS</small><button type="button" data-login="tech">Technician <b>arjun@northstar.com</b></button><button type="button" data-login="employee">Employee <b>priya@northstar.com</b></button></div></div></div>`);$(\'#login-form\').onsubmit=login;document.querySelectorAll(\'[data-login]\').forEach(b=>b.onclick=()=>{const tech=b.dataset.login===\'tech\';$(\'#email\').value=tech?\'arjun@northstar.com\':\'priya@northstar.com\';$(\'#password\').value=tech?\'arjun123\':\'priya123\';login()})}\nasync function login(e){if(e)e.preventDefault();const err=$(\'#login-error\');try{const d=await api(\'/login\',{method:\'POST\',body:JSON.stringify({email:$(\'#email\').value,password:$(\'#password\').value})});token=d.token;currentUser=d.user;localStorage.setItem(\'helpdesk_token\',token);$(\'#auth-screen\')?.remove();document.body.classList.remove(\'locked\');initApp()}catch(x){if(err)err.textContent=x.message}}\nfunction logout(){localStorage.removeItem(\'helpdesk_token\');token=null;location.reload()}\nfunction setUser(){const name=currentUser.name.split(\' \');const initials=name.map(x=>x[0]).join(\'\').slice(0,2);document.querySelectorAll(\'.top-avatar\').forEach(x=>x.textContent=initials);const card=document.querySelector(\'.user-card\');if(card)card.innerHTML=`<div class="avatar avatar-purple">${initials}</div><div><b>${esc(currentUser.name)}</b><span>${currentUser.role===\'technician\'?\'Support lead\':\'Employee\'}</span></div><button class="logout-btn" id="logout">↪</button>`;$(\'#logout\')?.addEventListener(\'click\',logout);const h=$(\'.hero h1\');if(h)h.innerHTML=`Good morning, ${esc(currentUser.name.split(\' \')[0])}<span>.</span>`;}\nasync function loadDashboard(){try{const d=await api(\'/dashboard\');document.querySelectorAll(\'.metric-value\')[0].textContent=String(d.open).padStart(2,\'0\');document.querySelectorAll(\'.metric-value\')[1].textContent=String(d.urgent).padStart(2,\'0\');document.querySelectorAll(\'.metric-value\')[2].textContent=String(d.assigned).padStart(2,\'0\');document.querySelectorAll(\'.metric-value\')[3].textContent=String(d.resolved).padStart(2,\'0\')}catch{document.querySelectorAll(\'.metric-value\').forEach(x=>x.textContent=\'—\')}}\nasync function loadTickets(query=\'\'){try{const d=await api(\'/tickets\'+query);allTickets=d.tickets;renderTickets(allTickets)}catch(x){toast(x.message,false)}}\nfunction renderTickets(items){const list=$(\'#ticket-list\');if(!items.length){list.innerHTML=\'<div class="empty-state">No tickets match this view.</div>\';return}list.innerHTML=items.map(t=>`<article class="ticket" data-ticket="${t.id}"><div class="priority-bar ${esc(t.priority)}"></div><div><div class="ticket-id">${esc(t.id_label)}</div><p class="ticket-title">${esc(t.title)}</p><div class="ticket-meta"><span>${esc(t.category.replace(\'-\', \' \'))}  ·  ${esc(t.reported_by)}</span></div></div><div class="ticket-side"><span class="status ${t.status===\'in-progress\'?\'progress\':t.status===\'resolved\'||t.status===\'closed\'?\'resolved\':\'open\'}">${esc(t.status.replace(\'-\', \' \'))}</span><small>${relative(t.updated_at)}</small></div></article>`).join(\'\');list.querySelectorAll(\'.ticket\').forEach(x=>x.onclick=()=>openTicket(Number(x.dataset.ticket)))}\nfunction relative(iso){const min=Math.max(1,Math.floor((Date.now()-new Date(iso).getTime())/60000));return min<60?`${min} min ago`:min<1440?`${Math.floor(min/60)} hr ago`:`${Math.floor(min/1440)} days ago`}\nasync function openTicket(id){try{const t=allTickets.find(x=>x.id===id);const h=await api(`/tickets/${id}/history`);const actions=currentUser.role===\'technician\'?`<div class="detail-actions"><select id="detail-status"><option ${t.status===\'open\'?\'selected\':\'\'}>open</option><option ${t.status===\'in-progress\'?\'selected\':\'\'}>in-progress</option><option ${t.status===\'resolved\'?\'selected\':\'\'}>resolved</option><option ${t.status===\'closed\'?\'selected\':\'\'}>closed</option></select><button class="primary-btn" id="save-detail">Save update</button></div>`:\'\';document.body.insertAdjacentHTML(\'beforeend\',`<div class="detail-backdrop" id="detail"><div class="detail-card"><button class="modal-close" id="close-detail">×</button><p class="eyebrow">${esc(t.id_label)} · ${esc(t.category)}</p><h2>${esc(t.title)}</h2><p class="detail-desc">${esc(t.description)}</p><div class="detail-meta"><span>Reported by<strong>${esc(t.reported_by)}</strong></span><span>Assigned to<strong>${esc(t.assigned_to||\'Unassigned\')}</strong></span><span>Priority<strong class="priority-text ${t.priority}">${esc(t.priority)}</strong></span></div><h3>Activity</h3><div class="history">${h.history.map(x=>`<div><i></i><p><b>${esc(x.changed_by_name)}</b> changed status from ${esc(x.old_status||\'new\')} to <b>${esc(x.new_status)}</b><small>${relative(x.created_at)}</small></p></div>`).join(\'\')}</div>${actions}</div></div>`);$(\'#close-detail\').onclick=()=>$(\'#detail\').remove();$(\'#save-detail\')?.addEventListener(\'click\',async()=>{try{await api(`/tickets/${id}`,{method:\'PATCH\',body:JSON.stringify({status:$(\'#detail-status\').value})});$(\'#detail\').remove();toast(\'Ticket updated successfully\');await refresh()}catch(x){toast(x.message,false)}})}catch(x){toast(x.message,false)}}\nasync function refresh(){setUser();await loadTickets();if(currentUser.role===\'technician\')await loadDashboard()}\nfunction setupInteractions(){const modal=$(\'#modal\');$(\'#new-ticket\').onclick=()=>{if(currentUser.role!==\'employee\'){toast(\'Only employees can create support requests\',false);return}modal.classList.add(\'open\')};$(\'#close-modal\').onclick=()=>modal.classList.remove(\'open\');modal.onclick=e=>{if(e.target===modal)modal.classList.remove(\'open\')};$(\'#ticket-form\').onsubmit=async e=>{e.preventDefault();const form=new FormData(e.target);try{const d=await api(\'/tickets\',{method:\'POST\',body:JSON.stringify({title:form.get(\'title\'),description:form.get(\'description\'),category:form.get(\'category\').toLowerCase().replace(\' \',\'-\'),priority:form.get(\'priority\').toLowerCase()})});modal.classList.remove(\'open\');e.target.reset();toast(`Ticket created • ML predicted ${d.ml.predicted_priority}`);await refresh()}catch(x){toast(x.message,false)}};document.querySelectorAll(\'.nav-item\').forEach(btn=>btn.addEventListener(\'click\',()=>{document.querySelectorAll(\'.nav-item\').forEach(x=>x.classList.remove(\'active\'));btn.classList.add(\'active\');$(\'#page-title\').textContent=btn.textContent.trim().replace(/\\d+$/,\'\').trim()}));document.querySelectorAll(\'.text-btn\').forEach(btn=>btn.addEventListener(\'click\',()=>document.querySelector(\'[data-view="queue"]\').click()));document.querySelectorAll(\'.tab\').forEach(tab=>tab.addEventListener(\'click\',()=>{document.querySelectorAll(\'.tab\').forEach(x=>x.classList.remove(\'active\'));tab.classList.add(\'active\');const label=tab.textContent.trim();loadTickets(label.startsWith(\'Urgent\')?\'?priority=urgent\':label.startsWith(\'Unassigned\')?\'?assignee_id=0\':\'\')}));}\nasync function initApp(){setUser();setupInteractions();await refresh()}\n(async()=>{if(!token){showLogin();return}try{const d=await api(\'/me\');currentUser=d.user;initApp()}catch{showLogin()}})();\n'

@app.get('/')
def index(): return HTML
@app.get('/styles.css')
def styles(): return CSS, 200, {'Content-Type':'text/css; charset=utf-8'}
@app.get('/app.js')
def scripts(): return JS, 200, {'Content-Type':'application/javascript; charset=utf-8'}

if __name__=='__main__':
    print('HelpDesk 360 running at http://localhost:' + str(os.environ.get('PORT',5173)))
    app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5173)),debug=False)

# Single-file bundle: the frontend assets are embedded above.
